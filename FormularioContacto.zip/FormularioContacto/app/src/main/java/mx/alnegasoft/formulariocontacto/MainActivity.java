package mx.alnegasoft.formulariocontacto;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnSiguiente = (Button) findViewById(R.id.btnSiguiente);

        btnSiguiente.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ConfirmarDatos.class);
                android.support.design.widget.TextInputLayout tilNombre = (android.support.design.widget.TextInputLayout) findViewById(R.id.tilNombre);
                android.support.design.widget.TextInputLayout tilTelefono = (android.support.design.widget.TextInputLayout) findViewById(R.id.tilTelefono);
                android.support.design.widget.TextInputLayout tilEmail = (android.support.design.widget.TextInputLayout) findViewById(R.id.tilEmail);
                android.support.design.widget.TextInputLayout tilDescripcion = (android.support.design.widget.TextInputLayout) findViewById(R.id.tilDescripcion);
                DatePicker dpFechaNacimiento = (DatePicker) findViewById(R.id.dpFechaNacimiento);

                intent.putExtra(getResources().getString(R.string.Nombre), tilNombre.getEditText().getText().toString());
                intent.putExtra(getResources().getString(R.string.Telefono), tilTelefono.getEditText().getText().toString());
                intent.putExtra(getResources().getString(R.string.Email), tilEmail.getEditText().getText().toString());
                intent.putExtra(getResources().getString(R.string.Descripcion), tilDescripcion.getEditText().getText().toString());
                intent.putExtra(getResources().getString(R.string.Fecha_Dia), String.valueOf(dpFechaNacimiento.getDayOfMonth()));
                intent.putExtra(getResources().getString(R.string.Fecha_Mes), String.valueOf(dpFechaNacimiento.getMonth()+1));
                intent.putExtra(getResources().getString(R.string.Fecha_Año), String.valueOf(dpFechaNacimiento.getYear()));


                startActivity(intent);
                //finish();
            }
        });

    }

}
