package mx.alnegasoft.formulariocontacto;

import android.content.Intent;
import android.support.annotation.StringRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ConfirmarDatos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmar_datos);

        Bundle parametros = getIntent().getExtras();

        String Nombre = parametros.getString(getResources().getString(R.string.Nombre));
        String Telefono = parametros.getString(getResources().getString(R.string.Telefono));
        String Email = parametros.getString(getResources().getString(R.string.Email));
        String Descripcion = parametros.getString(getResources().getString(R.string.Descripcion));
        String Dia = parametros.getString(getResources().getString(R.string.Fecha_Dia));
        String Mes = parametros.getString(getResources().getString(R.string.Fecha_Mes));
        String Año = parametros.getString(getResources().getString(R.string.Fecha_Año));

        TextView tvNombre = (TextView) findViewById(R.id.tvNombre);
        TextView tvTelefono = (TextView) findViewById(R.id.tvTelefono);
        TextView tvEmail = (TextView) findViewById(R.id.tvEmail);
        TextView tvDescipcion = (TextView) findViewById(R.id.tvDescripcion);
        TextView tvDia = (TextView) findViewById(R.id.tvDia);
        TextView tvMes= (TextView) findViewById(R.id.tvMes);
        TextView tvAño = (TextView) findViewById(R.id.tvAño);

        tvNombre.setText(Nombre);
        tvTelefono.setText(Telefono);
        tvEmail.setText(Email);
        tvDescipcion.setText(Descripcion);
        tvDia.setText(Dia);
        tvMes.setText(Mes);
        tvAño.setText(Año);


        Button btnEditar = (Button) findViewById(R.id.btnEditar);

        btnEditar.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
                //Intent intent = new Intent(ConfirmarDatos.this, MainActivity.class);
                //startActivity(intent);
            }
        });

    }

}
